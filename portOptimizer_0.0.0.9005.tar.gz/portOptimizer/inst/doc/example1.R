## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(knitr)
library(kableExtra)
library(portOptimizer)

## ----loaddata------------------------------------------------------------
assign("data", rafi_201811)

## ----showdata, echo=FALSE------------------------------------------------
kable(data$expected.returns[1:10,c(1,3,4,5,6,7)], digits = 3, caption = "Expected Returns")
kable(data$expected.cov[1:10,1:10], digits = 3, caption = "Expected Covariance")

## ----createobjectivefunction---------------------------------------------
calculate_my_objective_value <- function(x, expectedReturns, expectedCov, benchX, optParams){
  port_return <- calc_port_return(x, expectedReturns)
  port_risk <- calc_port_risk(x, expectedCov) 
  port_TE <- calc_port_risk(x - benchX, expectedCov)
  nnonzeroassets <- calc_nnonzeroassets(x)
  
  penalties <- (ifelse(port_risk <= optParams$maxRisk, 0, (port_risk - optParams$maxRisk)^2)  + 
               ifelse(port_TE <= optParams$maxTE, 0, (port_TE - optParams$maxTE)^2)  + 
               ifelse(nnonzeroassets >= optParams$minNAssets, 0, 
                      (nnonzeroassets - optParams$minNAssets)^2) +
               ifelse(nnonzeroassets <= optParams$maxNAssets, 0, 
                      (nnonzeroassets - optParams$maxNAssets)^2)) * optParams$penaltyFactor
  return(port_return - penalties)
}

## ----createDataForFunctions----------------------------------------------
x <- rep(1/nrow(data$expected.returns), nrow(data$expected.returns))
LB <- rep(0, nrow(data$expected.returns)) # lower bounds for weights
UB <- rep(1, nrow(data$expected.returns)) # upper bounds
benchX <- rep(0, nrow(data$expected.returns))
names(benchX) <- data$expected.returns$`Asset Class`
benchX[c('US Large', 'EAFE', 'Emerging Markets', 'US Aggregate')] <- c(0.36, 0.15, 0.09, 0.4)
optParams <- list(maxTE = 0.03, minNAssets = 3, maxNAssets = 10, LB=LB, UB=UB, 
                  penaltyFactor = 25e9)
# We use the risk of the benchmark as the maxRisk paramater
optParams$maxRisk <- calc_port_risk(benchX, as.matrix(data$expected.cov[,-1]))

calc_port_return(x, data$expected.returns$`Expected Return (Nominal)`)
calc_port_risk(x, as.matrix(data$expected.cov[,-1])) # cov needs to be a matrix, not a d.f.
calc_port_risk(x - benchX, as.matrix(data$expected.cov[,-1])) # This is tracking error
calc_nnonzeroassets(x)

# We use the risk of the benchmark as the maxRisk paramater
optParams$maxRisk <- calc_port_risk(benchX, as.matrix(data$expected.cov[,-1]))

## ----objectiveExample1---------------------------------------------------
# This is the value of the objective function
calculate_my_objective_value(x, data$expected.returns$`Expected Return (Nominal)`, 
                             as.matrix(data$expected.cov[,-1]), 
                             benchX, optParams)

## ------------------------------------------------------------------------
x <- benchX
calc_port_return(x, data$expected.returns$`Expected Return (Nominal)`)
calc_port_risk(x, as.matrix(data$expected.cov[,-1])) # cov needs to be a matrix, not a d.f.
calc_port_risk(benchX - x, as.matrix(data$expected.cov[,-1])) # This is tracking error
calc_nnonzeroassets(x)
calculate_my_objective_value(x, data$expected.returns$`Expected Return (Nominal)`, 
                             as.matrix(data$expected.cov[,-1]), 
                             benchX, optParams)

## ----runOptimizer--------------------------------------------------------
result <- maximize_objective(x, optParams$LB, optParams$UB, calculate_my_objective_value,
                           expectedReturns = data$expected.returns$`Expected Return (Nominal)`,
                           expectedCov = as.matrix(data$expected.cov[,-1]),
                           benchX = benchX, optParams = optParams)

## ----showResult----------------------------------------------------------
paste("Objective value: ", result$MaxObj)
cat("Vector of weights:")
result$x

paste("Return of Optimal Portfolio: ", calc_port_return(result$x, data$expected.returns$`Expected Return (Nominal)`))


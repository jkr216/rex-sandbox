## ----setup, include = FALSE, echo=FALSE, warning=FALSE-------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

library(magrittr)
library(knitr)
library(kableExtra)
library(tibble)
library(portOptimizer)


## ----createData----------------------------------------------------------
assign("data", rafi_201811)

# create a benchmark
benchX <- rep(0, nrow(data$expected.returns))
names(benchX) <- data$expected.returns$`Asset Class`
benchX[c('US Large', 'EAFE', 'Emerging Markets', 'US Aggregate')] <- c(0.36, 0.15, 0.09, 0.4)
benchX

# Lower and upper bounds
LB <- rep(0, nrow(data$expected.returns))
names(LB) <- data$expected.returns$`Asset Class`
LB["United States Cash"] <- .02

UB <- rep(1, nrow(data$expected.returns))
names(LB) <- data$expected.returns$`Asset Class`

# Current weights for calculating turnover
curX <- rep(0, nrow(data$expected.returns))
names(curX) <- data$expected.returns$`Asset Class`
curX["United States Cash"] <- 1

# definition of some groups
names.equity <- c("US Large", "US Small", "All country", "EAFE", "Emerging Markets", "Commodities", "REITS",
                 "US Commercial Real Estate")
names.fixed <- c("US Aggregate", "US Treasury Intermediate", "US Treasury Long", "US Treasury Short",
                "US Corporate Intermediate", "US Tips", "United States Cash") 
names.other <- c("Global Aggregate", "Global Ex-US Treasury", "Emerging Market (Local)", "Emerging Market (Non-Local)",
                "Global Ex-US Corporates", "Bank Loans", "US High Yield", "EM Cash", "Global DM Ex-US Long/Short Equity",
                "US Long/Short Equity", "Europe LBO", "US LBO") 
wts.equity <- numeric(nrow(data$expected.returns))
wts.equity[which(data$expected.returns$`Asset Class` %in% names.equity)] <- 1
wts.fixed <- numeric(nrow(data$expected.returns))
wts.fixed[which(data$expected.returns$`Asset Class` %in% names.fixed)] <- 1
wts.other <- numeric(nrow(data$expected.returns))
wts.other[which(data$expected.returns$`Asset Class` %in% names.other)] <- 1

wts.USLRelUS <- rep(0, nrow(data$expected.returns))
names(wts.USLRelUS) <- data$expected.returns$`Asset Class`
wts.USLRelUS[c('US Large', 'US Small')] <- c(0.25, -0.7)

## ------------------------------------------------------------------------
obj_definition <- addTermToObjective(name = "MaxReturn", 
                               type="maximize", 
                               funName=calc_port_return,
                               params = list(data$expected.returns$`Expected Return (Nominal)`)) %>%
            addTermToObjective(name = "Risk",
                               type = "constraint",
                               funName = calc_port_risk,
                               params = list(as.matrix(data$expected.cov[,-1])),
                               min = -Inf,
                               max = calc_port_risk(benchX, as.matrix(data$expected.cov[,-1]))) %>%
            addTermToObjective(name = "TrackingError",
                               type = "constraint",
                               funName = calc_port_TE,
                               params = list(benchX, as.matrix(data$expected.cov[,-1])),
                               min = -Inf,
                               max = 0.03) %>%
            addTermToObjective(name = "NAssets",
                               type = "constraint",
                               funName = calc_nnonzeroassets,
                               params = list(),
                               min = 3,
                               max = 10) %>%
           addTermToObjective(name = "MinNonZeroWt",
                              type = "constraint",
                              funName = calc_min_nonzero_weight,
                              params = list(LB),
                              min = 0.03,
                              max = Inf) %>%
          addTermToObjective(name = "Turnover",
                              type = "constraint",
                              funName = calc_turnover,
                              params = list(curX),
                              min = -Inf,
                              max = 1.0) %>%
          addTermToObjective(name = "RelWtsEquity",
                              type = "constraint",
                              funName = calc_weighted,
                              params = list(wts.equity),
                              min = sum(benchX[wts.equity == 1]) - 0.1,
                              max = sum(benchX[wts.equity == 1]) + 0.1) %>%
          addTermToObjective(name = "RelWtsFixed",
                              type = "constraint",
                              funName = calc_weighted,
                              params = list(wts.fixed),
                              min = sum(benchX[wts.fixed == 1]) - 0.1,
                              max = sum(benchX[wts.fixed == 1]) + 0.1) %>%
          addTermToObjective(name = "RelWtsOther",
                              type = "constraint",
                              funName = calc_weighted,
                              params = list(wts.other),
                              min = sum(benchX[wts.other == 1]) - 0.1,
                              max = sum(benchX[wts.other == 1]) + 0.1) %>%
          addTermToObjective(name = "WtsFixed",
                              type = "constraint",
                              funName = calc_weighted,
                              params = list(wts.fixed),
                              min = 0.1,
                              max = Inf)  %>%
          addTermToObjective(name = "USLRelUS",
                              type = "constraint",
                              funName = calc_weighted,
                              params = list(wts.USLRelUS),
                              min = 0,
                              max = Inf) 
  

## ------------------------------------------------------------------------
calc_objective(benchX, obj_definition = obj_definition)

## ------------------------------------------------------------------------
calc_objective_terms(x, obj_definition)

## ------------------------------------------------------------------------
calc_objective(curX, obj_definition = obj_definition)

## ------------------------------------------------------------------------
calc_objective_terms(curX, obj_definition)

## ------------------------------------------------------------------------
result <- maximize_objective(benchX, LB, UB, calc_objective, obj_definition=obj_definition)
result

## ------------------------------------------------------------------------
calc_objective(result$x, obj_definition = obj_definition)

## ------------------------------------------------------------------------
calc_objective_terms(result$x, obj_definition)

